
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

#define PI 3.141592653589793
#define E 2.718281828459045

// Function declarations
double add(double a, double b);
double subtract(double a, double b);
double multiply(double a, double b);
double divide(double a, double b);
int modulus(int a, int b);

double sine(double angle);
double cosine(double angle);
double tangent(double angle);

double square(double n);
double cube(double n);
double power(double base, double exponent);
double squareRoot(double n);
double cubeRoot(double n);

double naturalLog(double n);
double commonLog(double n);

double factorial(int n);
double percentage(double percent, double number);
double reciprocal(double n);

// Input functions
int readInteger(const char *message, int *value);
int readNumber(const char *message, double *value);

// Menu functions
void arithmeticMenu(void);
void trigonometryMenu(void);
void powerRootMenu(void);
void logarithmMenu(void);
void otherFunctionsMenu(void);
void constantsMenu(void);

// MAIN FUNCTION

int main()
{
    int choice = 0;

    do
    {
        printf("\n========================================\n");
        printf("          SCIENTIFIC CALCULATOR\n");
        printf("========================================\n");

        printf("1. Basic Arithmetic\n");
        printf("2. Trigonometric Functions\n");
        printf("3. Power and Root Functions\n");
        printf("4. Logarithmic Functions\n");
        printf("5. Other Mathematical Functions\n");
        printf("6. Mathematical Constants\n");
        printf("7. Exit\n");

        if(!readInteger("\nEnter your choice: ", &choice))
        {
            printf("Invalid input! Please enter a valid integer.\n");
            continue;
        }

        switch(choice)
        {
            case 1:
                arithmeticMenu();
                break;

            case 2:
                trigonometryMenu();
                break;

            case 3:
                powerRootMenu();
                break;

            case 4:
                logarithmMenu();
                break;

            case 5:
                otherFunctionsMenu();
                break;

            case 6:
                constantsMenu();
                break;

            case 7:
                printf("\nThank you for using the Scientific Calculator!\n");
                printf("Program terminated successfully.\n");
                break;

            default:
                printf("\nInvalid choice! Please select from 1 to 7.\n");
        }

    } while(choice != 7);

    return 0;
}

// INPUT FUNCTIONS

int readInteger(const char *message, int *value)
{
    char line[100];
    char *end;
    long result;

    printf("%s", message);

    if(fgets(line, sizeof(line), stdin) == NULL)
        return 0;

    errno = 0;
    result = strtol(line, &end, 10);

    if(end == line || errno == ERANGE ||
       result < INT_MIN || result > INT_MAX)
        return 0;

    while(*end == ' ' || *end == '\t')
        end++;

    if(*end != '\n' && *end != '\0')
        return 0;

    *value = (int)result;
    return 1;
}

int readNumber(const char *message, double *value)
{
    char line[100];
    char *end;
    double result;

    printf("%s", message);

    if(fgets(line, sizeof(line), stdin) == NULL)
        return 0;

    errno = 0;
    result = strtod(line, &end);

    if(end == line || errno == ERANGE || !isfinite(result))
        return 0;

    while(*end == ' ' || *end == '\t')
        end++;

    if(*end != '\n' && *end != '\0')
        return 0;

    *value = result;
    return 1;
}

// BASIC ARITHMETIC MENU

void arithmeticMenu(void)
{
    int operation;
    int a, b;
    double num1, num2;

    printf("\n---------- BASIC ARITHMETIC ----------\n");
    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Division\n");
    printf("5. Modulus\n");

    if(!readInteger("Select operation: ", &operation))
    {
        printf("Invalid input!\n");
        return;
    }

    if(operation < 1 || operation > 5)
    {
        printf("Invalid operation!\n");
        return;
    }

    if(operation == 5)
    {
        if(!readInteger("Enter first integer: ", &a))
            return;

        if(!readInteger("Enter second integer: ", &b))
            return;

        if(b == 0)
        {
            printf("Error! Modulus by zero is not allowed.\n");
            return;
        }

        if(a == INT_MIN && b == -1)
        {
            printf("Error! Result is outside the integer range.\n");
            return;
        }

        printf("Result: %d\n", modulus(a, b));
        return;
    }

    if(!readNumber("Enter first number: ", &num1))
    {
        printf("Invalid number!\n");
        return;
    }

    if(!readNumber("Enter second number: ", &num2))
    {
        printf("Invalid number!\n");
        return;
    }

    switch(operation)
    {
        case 1:
            printf("Result: %.4lf\n", add(num1, num2));
            break;

        case 2:
            printf("Result: %.4lf\n", subtract(num1, num2));
            break;

        case 3:
            printf("Result: %.4lf\n", multiply(num1, num2));
            break;

        case 4:
            if(num2 == 0)
                printf("Error! Division by zero is not allowed.\n");
            else
                printf("Result: %.4lf\n", divide(num1, num2));
            break;
    }
}

// TRIGONOMETRIC MENU

void trigonometryMenu(void)
{
    int operation;
    double angle;

    printf("\n------- TRIGONOMETRIC FUNCTIONS -------\n");
    printf("1. Sine (sin)\n");
    printf("2. Cosine (cos)\n");
    printf("3. Tangent (tan)\n");

    if(!readInteger("Select operation: ", &operation))
    {
        printf("Invalid input!\n");
        return;
    }

    if(operation < 1 || operation > 3)
    {
        printf("Invalid operation!\n");
        return;
    }

    if(!readNumber("Enter angle in degrees: ", &angle))
    {
        printf("Invalid angle!\n");
        return;
    }

    switch(operation)
    {
        case 1:
            printf("Result: %.4lf\n", sine(angle));
            break;

        case 2:
            printf("Result: %.4lf\n", cosine(angle));
            break;

        case 3:
            if(fabs(cosine(angle)) < 1e-10)
                printf("Error! Tangent is undefined at this angle.\n");
            else
                printf("Result: %.4lf\n", tangent(angle));
            break;
    }
}

// POWER AND ROOT MENU

void powerRootMenu(void)
{
    int operation;
    double num1, num2, result;

    printf("\n-------- POWER AND ROOT FUNCTIONS --------\n");
    printf("1. Square\n");
    printf("2. Cube\n");
    printf("3. Power\n");
    printf("4. Square Root\n");
    printf("5. Cube Root\n");

    if(!readInteger("Select operation: ", &operation))
    {
        printf("Invalid input!\n");
        return;
    }

    if(operation < 1 || operation > 5)
    {
        printf("Invalid operation!\n");
        return;
    }

    if(!readNumber("Enter number: ", &num1))
    {
        printf("Invalid number!\n");
        return;
    }

    switch(operation)
    {
        case 1:
            printf("Result: %.4lf\n", square(num1));
            break;

        case 2:
            printf("Result: %.4lf\n", cube(num1));
            break;

        case 3:
            if(!readNumber("Enter exponent: ", &num2))
            {
                printf("Invalid exponent!\n");
                return;
            }

            if(num1 == 0 && num2 <= 0)
            {
                printf("Error! Zero cannot be raised to this power.\n");
                return;
            }

            if(num1 < 0 && num2 != trunc(num2))
            {
                printf("Error! Invalid power for negative base.\n");
                return;
            }

            result = power(num1, num2);

            if(!isfinite(result))
                printf("Error! Result is outside the supported range.\n");
            else
                printf("Result: %.4lf\n", result);

            break;

        case 4:
            if(num1 < 0)
                printf("Error! Square root of a negative number is not real.\n");
            else
                printf("Result: %.4lf\n", squareRoot(num1));
            break;

        case 5:
            printf("Result: %.4lf\n", cubeRoot(num1));
            break;
    }
}

// LOGARITHMIC MENU

void logarithmMenu(void)
{
    int operation;
    double num;

    printf("\n-------- LOGARITHMIC FUNCTIONS --------\n");
    printf("1. Natural Logarithm (ln)\n");
    printf("2. Common Logarithm (log base 10)\n");

    if(!readInteger("Select operation: ", &operation))
    {
        printf("Invalid input!\n");
        return;
    }

    if(operation < 1 || operation > 2)
    {
        printf("Invalid operation!\n");
        return;
    }

    if(!readNumber("Enter a positive number: ", &num))
    {
        printf("Invalid number!\n");
        return;
    }

    if(num <= 0)
    {
        printf("Error! Logarithm is defined only for positive numbers.\n");
        return;
    }

    if(operation == 1)
        printf("Result: %.4lf\n", naturalLog(num));
    else
        printf("Result: %.4lf\n", commonLog(num));
}

// OTHER MATHEMATICAL FUNCTIONS

void otherFunctionsMenu(void)
{
    int operation;
    int n;
    double num1, num2;

    printf("\n----- OTHER MATHEMATICAL FUNCTIONS -----\n");
    printf("1. Factorial\n");
    printf("2. Percentage\n");
    printf("3. Reciprocal\n");

    if(!readInteger("Select operation: ", &operation))
    {
        printf("Invalid input!\n");
        return;
    }

    if(operation < 1 || operation > 3)
    {
        printf("Invalid operation!\n");
        return;
    }

    switch(operation)
    {
        case 1:
            if(!readInteger("Enter a non-negative integer (0-170): ", &n))
            {
                printf("Invalid integer!\n");
                return;
            }

            if(n < 0 || n > 170)
            {
                printf("Error! Enter an integer between 0 and 170.\n");
                return;
            }

            printf("Result: %.0lf\n", factorial(n));
            break;

        case 2:
            if(!readNumber("Enter percentage: ", &num1))
                return;

            if(!readNumber("Enter the number: ", &num2))
                return;

            printf("Result: %.4lf\n", percentage(num1, num2));
            break;

        case 3:
            if(!readNumber("Enter number: ", &num1))
                return;

            if(num1 == 0)
                printf("Error! Zero has no reciprocal.\n");
            else
                printf("Result: %.4lf\n", reciprocal(num1));
            break;
    }
}

// MATHEMATICAL CONSTANTS

void constantsMenu(void)
{
    printf("\n-------- MATHEMATICAL CONSTANTS --------\n");
    printf("PI (π) = %.10lf\n", PI);
    printf("Euler's Number (e) = %.10lf\n", E);
}

// ARITHMETIC FUNCTIONS

double add(double a, double b)
{
    return a + b;
}

double subtract(double a, double b)
{
    return a - b;
}

double multiply(double a, double b)
{
    return a * b;
}

double divide(double a, double b)
{
    return a / b;
}

int modulus(int a, int b)
{
    return a % b;
}

// TRIGONOMETRIC FUNCTIONS

double sine(double angle)
{
    return sin(angle * PI / 180.0);
}

double cosine(double angle)
{
    return cos(angle * PI / 180.0);
}

double tangent(double angle)
{
    return tan(angle * PI / 180.0);
}

// POWER AND ROOT FUNCTIONS

double square(double n)
{
    return n * n;
}

double cube(double n)
{
    return n * n * n;
}

double power(double base, double exponent)
{
    return pow(base, exponent);
}

double squareRoot(double n)
{
    return sqrt(n);
}

double cubeRoot(double n)
{
    return cbrt(n);
}

// LOGARITHMIC FUNCTIONS

double naturalLog(double n)
{
    return log(n);
}

double commonLog(double n)
{
    return log10(n);
}

// OTHER MATHEMATICAL FUNCTIONS

double factorial(int n)
{
    double result = 1;

    for(int i = 1; i <= n; i++)
        result *= i;

    return result;
}

double percentage(double percent, double number)
{
    return (percent / 100.0) * number;
}

double reciprocal(double n)
{
    return 1.0 / n;
}
